public class Persona {
    private int minutoLlegada;
    private boolean esPreferente;

    public Persona(int minutoLlegada, boolean esPreferente) {
        this.minutoLlegada = minutoLlegada;
        this.esPreferente = esPreferente;
    }

    public int obtenerTiempoEspera(int minutoActual) {
        return minutoActual - this.minutoLlegada;
    }

    public boolean tieneDerechoPreferente() {
        return this.esPreferente;
    }
}