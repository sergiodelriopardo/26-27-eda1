public class AplicacionReto {
    public static void main(String[] args) {
        SimuladorCajas simulador = new SimuladorCajas();
        simulador.iniciar(120); 
    }
}