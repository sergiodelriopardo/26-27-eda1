import java.util.Random;

public class Fila {
    private Persona[] personasEnFila;
    private int cantidad;
    private Random aleatorio;

    public Fila(int capacidadMaxima) {
        this.personasEnFila = new Persona[capacidadMaxima];
        this.cantidad = 0;
        this.aleatorio = new Random();
    }

    public boolean estaVacia() {
        return cantidad == 0;
    }

    public int obtenerLongitud() {
        return cantidad;
    }

    public void incorporarAlFinal(Persona nueva) {
        if (cantidad < personasEnFila.length) {
            personasEnFila[cantidad] = nueva;
            cantidad++;
        }
    }

    public void atenderPrimero() {
        eliminarPersonaEnPosicion(0);
    }

    public void incorporarPreferente(Persona nueva) { 
        int posicionInsertar = 0;
        for (int i = 0; i < cantidad; i++) {
            if (personasEnFila[i].tieneDerechoPreferente() == true) {
                posicionInsertar = i + 1;
            }
        }
        insertarEnPosicion(nueva, posicionInsertar);
    }

    public void colarseDetrasDeAlguien(Persona colado) {
        int posicionConocido = aleatorio.nextInt(cantidad);
        insertarEnPosicion(colado, posicionConocido + 1);
    }

    public void gestionarAburrimiento(int minutoActual, int minutosLimite, double probabilidad) {
        for (int i = cantidad - 1; i >= 0; i--) {
            if (personasEnFila[i].obtenerTiempoEspera(minutoActual) > minutosLimite) {
                if (aleatorio.nextDouble() <= probabilidad) {
                    eliminarPersonaEnPosicion(i);
                }
            }
        }
    }

    public void delegarCompraEIrse() {
        int posicionAAbandonar = aleatorio.nextInt(cantidad);
        eliminarPersonaEnPosicion(posicionAAbandonar);
    }

    private void insertarEnPosicion(Persona p, int posicion) {
        if (cantidad < personasEnFila.length) {
            for (int i = cantidad; i > posicion; i--) {
                personasEnFila[i] = personasEnFila[i - 1];
            }
            personasEnFila[posicion] = p;
            cantidad++;
        }
    }

    private void eliminarPersonaEnPosicion(int posicion) {
        if (posicion >= 0 && posicion < cantidad) {
            for (int i = posicion; i < cantidad - 1; i++) {
                personasEnFila[i] = personasEnFila[i + 1];
            }
            personasEnFila[cantidad - 1] = null; 
            cantidad--;
        }
    }
}