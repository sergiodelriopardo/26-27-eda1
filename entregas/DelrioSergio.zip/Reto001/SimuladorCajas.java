import java.util.Random;

public class SimuladorCajas {
    private Fila fila;
    private int personasAtendidas;
    private Random aleatorio;

    public SimuladorCajas() {
        this.fila = new Fila(100); 
        this.personasAtendidas = 0;
        this.aleatorio = new Random();
    }

    public void iniciar(int duracionMinutos) {
        for (int minutoActual = 1; minutoActual <= duracionMinutos; minutoActual++) {
            
            gestionarLlegadaNormal(minutoActual);
                
            if (aleatorio.nextDouble() <= 0.4) {
                if (fila.estaVacia() == false) {
                fila.atenderPrimero();
                personasAtendidas++;
                }
            }

            if (minutoActual >= 20) {
                gestionarEventosExtendidos(minutoActual);
            }

            System.out.println("Minuto " + minutoActual + " | Fila: " + fila.obtenerLongitud() + " personas.");
        }

        mostrarReporteFinal();
    }

    private void gestionarLlegadaNormal(int minutoActual) {
        if (aleatorio.nextDouble() <= 0.6) {
            if (fila.obtenerLongitud() >= 30) {
                if (aleatorio.nextDouble() <= 0.5) {
                    return; 
                }
            }
            Persona nuevaPersona = new Persona(minutoActual, false);
            fila.incorporarAlFinal(nuevaPersona);
        }
    }

    private void atenderCliente() {
        if (aleatorio.nextDouble() <= 0.4) {
            if (fila.estaVacia() == false) {
                fila.atenderPrimero();
                personasAtendidas++;
            }
        }
    }

    private void gestionarEventosExtendidos(int minutoActual) {
        if (minutoActual % 5 == 0) {
            fila.gestionarAburrimiento(minutoActual, 8, 0.3);
        }

        if (aleatorio.nextDouble() <= 0.1) {
            Persona preferente = new Persona(minutoActual, true);
            fila.incorporarPreferente(preferente);
        }

        if (aleatorio.nextDouble() <= 0.05 && fila.obtenerLongitud() > 1) {
            Persona colado = new Persona(minutoActual, false);
            fila.colarseDetrasDeAlguien(colado);
        }

        if (aleatorio.nextDouble() <= 0.05 && fila.obtenerLongitud() > 1) {
            fila.delegarCompraEIrse();
        }

        if (minutoActual % 15 == 0 && fila.obtenerLongitud() > 25) {
            System.out.println("Pasen por esta caja en orden de fila.");
        }
    }

    private void mostrarReporteFinal() {
        System.out.println("Personas atendidas: " + personasAtendidas);
        System.out.println("Personas que quedaron en fila: " + fila.obtenerLongitud());
    }
}